import service
globals().update(service)
