import os, sys
import zipfile
import copy
import builtins
zip_path=os.path.dirname(__file__)
Zipfile=zipfile.ZipFile(zip_path)

old_open=copy.copy(open)
def new_open(path,mode='r'):
    path=os.path.abspath(path)
    if path.startswith(zip_path) or path.startswith(zip_path+os.sep):
        path=os.path.relpath(path,zip_path)
        return Zipfile.open(path)
    else:
        return old_open(path,mode)

builtins.open=new_open

sys.path.insert(0,os.path.join(zip_path,"_vendor"))

import service

if __name__=="__main__":
    service.main()
